
WebView Extension Communications Demo: App
=======



[Zipfile](http://developer.chrome.com/extensions/examples/api/webview/comm_demo_app.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [runtime.connect](https://developer.chrome.com/extensions/runtime#method-connect)