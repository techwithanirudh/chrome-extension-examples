
Omnibox New Tab Search
=======

Type 'nt' plus a search term into the Omnibox to open search in new tab.

[Zipfile](http://developer.chrome.com/extensions/examples/api/omnibox/newtab_search.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [omnibox.onInputEntered](https://developer.chrome.com/extensions/omnibox#event-onInputEntered)
* [tabs.create](https://developer.chrome.com/extensions/tabs#method-create)