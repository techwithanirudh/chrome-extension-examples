
History Override
=======

Overrides the History Page

[Zipfile](http://developer.chrome.com/extensions/examples/api/history/historyOverride.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [history.deleteAll](https://developer.chrome.com/extensions/history#method-deleteAll)
* [history.deleteUrl](https://developer.chrome.com/extensions/history#method-deleteUrl)
* [history.search](https://developer.chrome.com/extensions/history#method-search)