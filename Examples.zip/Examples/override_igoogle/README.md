
iGoogle new tab page
=======

Override the new tab page with iGoogle

[Zipfile](http://developer.chrome.com/extensions/examples/api/override/override_igoogle.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

