
Webview transparency
=======

Sample of the webview.captureVisibleRegion api

[Zipfile](http://developer.chrome.com/extensions/examples/api/webview/capturevisibleregion.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

