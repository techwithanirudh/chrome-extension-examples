
News Reader
=======

Displays the first 5 items from the 'Google News - top news' RSS feed in a popup.

[Zipfile](http://developer.chrome.com/extensions/examples/extensions/news_a11y.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [tabs.create](https://developer.chrome.com/extensions/tabs#method-create)