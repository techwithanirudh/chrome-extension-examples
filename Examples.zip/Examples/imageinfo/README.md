
Imageinfo
=======

Get image info for images, including EXIF data

[Zipfile](http://developer.chrome.com/extensions/examples/extensions/imageinfo.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [contextMenus.create](https://developer.chrome.com/extensions/contextMenus#method-create)
* [tabs.getCurrent](https://developer.chrome.com/extensions/tabs#method-getCurrent)
* [windows.create](https://developer.chrome.com/extensions/windows#method-create)
* [windows.update](https://developer.chrome.com/extensions/windows#method-update)