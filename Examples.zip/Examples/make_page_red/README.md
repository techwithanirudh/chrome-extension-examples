
Page Redder
=======

Make the current page red

[Zipfile](http://developer.chrome.com/extensions/examples/api/browserAction/make_page_red.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [browserAction.onClicked](https://developer.chrome.com/extensions/browserAction#event-onClicked)
* [tabs.executeScript](https://developer.chrome.com/extensions/tabs#method-executeScript)