
News Reader (by Google)
=======

Displays the latest stories from Google News in a popup.

[Zipfile](http://developer.chrome.com/extensions/examples/extensions/news.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [extension.getURL](https://developer.chrome.com/extensions/extension#method-getURL)
* [i18n.getMessage](https://developer.chrome.com/extensions/i18n#method-getMessage)
* [tabs.create](https://developer.chrome.com/extensions/tabs#method-create)