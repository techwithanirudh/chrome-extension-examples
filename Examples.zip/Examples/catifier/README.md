
Catifier
=======

Moar cats!

[Zipfile](http://developer.chrome.com/extensions/examples/extensions/catifier.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [declarativeWebRequest.IgnoreRules](https://developer.chrome.com/extensions/declarativeWebRequest#type-IgnoreRules)
* [declarativeWebRequest.RedirectRequest](https://developer.chrome.com/extensions/declarativeWebRequest#type-RedirectRequest)
* [declarativeWebRequest.RequestMatcher](https://developer.chrome.com/extensions/declarativeWebRequest#type-RequestMatcher)
* [runtime.lastError](https://developer.chrome.com/extensions/runtime#property-lastError)
* [runtime.onInstalled](https://developer.chrome.com/extensions/runtime#event-onInstalled)