
`extension.isAllowedFileSchemeAccess` and `extension.isAllowedIncognitoAccess` Example
=======

Demonstrates the `extension.isAllowedFileSchemeAccess` and `extesion.isAllowedIncognitoAccess` APIs

[Zipfile](http://developer.chrome.com/extensions/examples/api/extension/isAllowedAccess.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [extension.isAllowedFileSchemeAccess](https://developer.chrome.com/extensions/extension#method-isAllowedFileSchemeAccess)
* [extension.isAllowedIncognitoAccess](https://developer.chrome.com/extensions/extension#method-isAllowedIncognitoAccess)