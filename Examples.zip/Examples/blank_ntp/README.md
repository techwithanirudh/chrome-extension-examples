
Blank new tab page
=======

Override the new tab page with a blank one

[Zipfile](http://developer.chrome.com/extensions/examples/api/override/blank_ntp.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

