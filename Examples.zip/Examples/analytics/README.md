
Event Tracking with Google Analytics
=======

A sample extension which uses Google Analytics to track usage.

[Zipfile](http://developer.chrome.com/extensions/examples/tutorials/analytics.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

