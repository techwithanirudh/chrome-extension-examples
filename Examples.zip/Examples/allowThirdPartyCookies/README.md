
Block/allow third-party cookies API example extension
=======

Sample extension which demonstrates how to access a preference.

[Zipfile](http://developer.chrome.com/extensions/examples/api/preferences/allowThirdPartyCookies.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [extension.isAllowedIncognitoAccess](https://developer.chrome.com/extensions/extension#method-isAllowedIncognitoAccess)