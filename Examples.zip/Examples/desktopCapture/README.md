
Desktop Capture Example
=======

Show desktop media picker UI

[Zipfile](http://developer.chrome.com/extensions/examples/api/desktopCapture.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [desktopCapture.cancelChooseDesktopMedia](https://developer.chrome.com/extensions/desktopCapture#method-cancelChooseDesktopMedia)
* [desktopCapture.chooseDesktopMedia](https://developer.chrome.com/extensions/desktopCapture#method-chooseDesktopMedia)
* [runtime.onMessage](https://developer.chrome.com/extensions/runtime#event-onMessage)
* [runtime.sendMessage](https://developer.chrome.com/extensions/runtime#method-sendMessage)