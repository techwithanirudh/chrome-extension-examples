
Sample Extension Commands extension
=======

Press Ctrl+Shift+F to open the browser action popup, press Ctrl+Shift+Y to send an event.

[Zipfile](http://developer.chrome.com/extensions/examples/api/commands.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [commands.onCommand](https://developer.chrome.com/extensions/commands#event-onCommand)