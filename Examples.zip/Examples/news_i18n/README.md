
News Reader
=======

Displays the first 5 items from the '$Google$ News - top news' RSS feed in a popup.

[Zipfile](http://developer.chrome.com/extensions/examples/extensions/news_i18n.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

