
BrowsingData API: Basics
=======

A trivial usage example.

[Zipfile](http://developer.chrome.com/extensions/examples/api/browsingData/basic.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [browsingData.remove](https://developer.chrome.com/extensions/browsingData#method-remove)