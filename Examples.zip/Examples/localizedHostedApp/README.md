
Minimal Localized Hosted App
=======

This is the minimal set of data required to upload a localized hosted application to the web store.

[Zipfile](http://developer.chrome.com/extensions/examples/api/i18n/localizedHostedApp.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

