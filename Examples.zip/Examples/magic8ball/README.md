
NTP prototyping extension
=======

extension to prototype new NTP designs

[Zipfile](http://developer.chrome.com/extensions/examples/api/topsites/magic8ball.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [topSites.get](https://developer.chrome.com/extensions/topSites#method-get)