
Detect Language
=======

Detects up to 3 languages and their percentages of the provided string

[Zipfile](http://developer.chrome.com/extensions/examples/api/i18n/detectLanguage.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [i18n.detectLanguage](https://developer.chrome.com/extensions/i18n#method-detectLanguage)