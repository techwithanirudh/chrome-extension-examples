
CatBlock
=======

I can't has cheezburger!

[Zipfile](http://developer.chrome.com/extensions/examples/extensions/catblock.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [webRequest.onBeforeRequest](https://developer.chrome.com/extensions/webRequest#event-onBeforeRequest)