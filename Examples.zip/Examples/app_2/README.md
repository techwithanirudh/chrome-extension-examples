
Chromium IRC App
=======



[Zipfile](http://developer.chrome.com/extensions/examples/extensions/irc/app.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

