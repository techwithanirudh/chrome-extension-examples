
Download Filename Controller
=======

Download Filename Controller

[Zipfile](http://developer.chrome.com/extensions/examples/api/downloads/download_filename_controller.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [downloads.onDeterminingFilename](https://developer.chrome.com/extensions/downloads#event-onDeterminingFilename)