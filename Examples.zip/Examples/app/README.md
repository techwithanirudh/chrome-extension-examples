
Native Messaging Example
=======

Send a message to a native application.

[Zipfile](http://developer.chrome.com/extensions/examples/api/nativeMessaging/app.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [runtime.connectNative](https://developer.chrome.com/extensions/runtime#method-connectNative)