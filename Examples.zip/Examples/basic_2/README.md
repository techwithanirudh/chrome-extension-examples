
Context Menus Sample
=======

Shows some of the features of the Context Menus API

[Zipfile](http://developer.chrome.com/extensions/examples/api/contextMenus/basic.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [contextMenus.create](https://developer.chrome.com/extensions/contextMenus#method-create)
* [extension.lastError](https://developer.chrome.com/extensions/extension#property-lastError)