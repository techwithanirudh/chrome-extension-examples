
Notification Demo
=======

Shows off desktop notifications, which are "toast" windows that pop up on the desktop.

[Zipfile](http://developer.chrome.com/extensions/examples/api/notifications.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

