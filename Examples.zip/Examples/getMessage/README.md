
AcceptLanguage
=======

Returns accept languages of the browser

[Zipfile](http://developer.chrome.com/extensions/examples/api/i18n/getMessage.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [i18n.getAcceptLanguages](https://developer.chrome.com/extensions/i18n#method-getAcceptLanguages)
* [i18n.getMessage](https://developer.chrome.com/extensions/i18n#method-getMessage)