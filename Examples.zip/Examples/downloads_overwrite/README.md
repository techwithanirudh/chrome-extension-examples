
Downloads Overwrite Existing Files
=======

All downloads overwrite existing files instead of adding ' (1)', ' (2)', etc.

[Zipfile](http://developer.chrome.com/extensions/examples/api/downloads/downloads_overwrite.zip)

Content is licensed under the [Google BSD License](https://developers.google.com/open-source/licenses/bsd).

Calls
-----

* [downloads.onDeterminingFilename](https://developer.chrome.com/extensions/downloads#event-onDeterminingFilename)